These files are downloaded from http://www-cs-students.stanford.edu/~tjw/jsbn/

Here is a list of changes made to this library:

 - https://github.com/travist/jsencrypt/pull/6

